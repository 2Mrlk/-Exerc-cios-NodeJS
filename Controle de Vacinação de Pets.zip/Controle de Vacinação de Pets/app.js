const express = require('express');
const app = express();


app.use(express.json());


let vacinacoes = [
    {
        id: 1,
        petNome: "Rex",
        tipoPet: "Cachorro",
        vacina: "Raiva",
        dataAplicacao: "2025-09-15"
    }
];


function gerarNovoId() {
    return vacinacoes.length > 0 ? vacinacoes[vacinacoes.length - 1].id + 1 : 1;
}


app.post('/vacinacoes', (req, res) => {
    const { petNome, tipoPet, vacina, dataAplicacao } = req.body;

    if (!petNome || !tipoPet || !vacina || !dataAplicacao) {
        return res.status(400).json({ error: "Todos os campos são obrigatórios." });
    }

    const novaVacinacao = {
        id: gerarNovoId(),
        petNome,
        tipoPet,
        vacina,
        dataAplicacao
    };

    vacinacoes.push(novaVacinacao);
    res.status(201).json({ message: "Vacinação registrada com sucesso!", vacinacao: novaVacinacao });
});

app.get('/vacinacoes', (req, res) => {
    res.json(vacinacoes);
});


app.get('/vacinacoes/:id', (req, res) => {
    const vacinacao = vacinacoes.find(v => v.id === parseInt(req.params.id));
    if (!vacinacao) return res.status(404).json({ error: 'Registro de vacinação não encontrado.' });
    res.json(vacinacao);
});


app.put('/vacinacoes/:id', (req, res) => {
    const { petNome, tipoPet, vacina, dataAplicacao } = req.body;
    const vacinacao = vacinacoes.find(v => v.id === parseInt(req.params.id));

    if (!vacinacao) return res.status(404).json({ error: 'Registro não encontrado para atualização.' });


    vacinacao.petNome = petNome || vacinacao.petNome;
    vacinacao.tipoPet = tipoPet || vacinacao.tipoPet;
    vacinacao.vacina = vacina || vacinacao.vacina;
    vacinacao.dataAplicacao = dataAplicacao || vacinacao.dataAplicacao;

    res.json({ message: "Registro de vacinação atualizado com sucesso.", vacinacao });
});


app.delete('/vacinacoes/:id', (req, res) => {
    const index = vacinacoes.findIndex(v => v.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ error: 'Registro não encontrado para exclusão.' });

    const removido = vacinacoes.splice(index, 1);
    res.json({ message: "Registro de vacinação removido com sucesso.", removido });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`http://localhost:${PORT}`);
});

