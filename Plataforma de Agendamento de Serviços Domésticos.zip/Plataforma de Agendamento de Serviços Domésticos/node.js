const express = require('express');
const app = express();


app.use(express.json());


let usuarios = [];
let servicos = [
  { id: 1, nome: "Diarista" },
  { id: 2, nome: "Eletricista" },
  { id: 3, nome: "Encanador" },
];
let agendamentos = [];

let nextUserId = 1;
let nextAgendamentoId = 1;


app.post('/usuarios', (req, res) => {
  const { nome, tipo } = req.body; // tipo: 'cliente' ou 'prestador'
  if (!nome || !tipo || !['cliente', 'prestador'].includes(tipo)) {
    return res.status(400).json({ message: "Dados inválidos. Informe nome e tipo (cliente/prestador)." });
  }

  const novoUsuario = { id: nextUserId++, nome, tipo };
  usuarios.push(novoUsuario);
  res.status(201).json(novoUsuario);
});

app.get('/usuarios', (req, res) => {
  res.json(usuarios);
});


app.get('/servicos', (req, res) => {
  res.json(servicos);
});


app.post('/agendamentos', (req, res) => {
  const { clienteId, prestadorId, servicoId, data } = req.body;

  const cliente = usuarios.find(u => u.id === clienteId && u.tipo === 'cliente');
  const prestador = usuarios.find(u => u.id === prestadorId && u.tipo === 'prestador');
  const servico = servicos.find(s => s.id === servicoId);

  if (!cliente || !prestador || !servico || !data) {
    return res.status(400).json({ message: "Dados inválidos para agendamento." });
  }

  const novoAgendamento = {
    id: nextAgendamentoId++,
    cliente,
    prestador,
    servico,
    data
  };

  agendamentos.push(novoAgendamento);
  res.status(201).json({ message: "Agendamento criado com sucesso!", agendamento: novoAgendamento });
});
app.get('/agendamentos', (req, res) => {
  res.json(agendamentos);
});

app.delete('/agendamentos/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = agendamentos.findIndex(a => a.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Agendamento não encontrado." });
  }

  agendamentos.splice(index, 1);
  res.json({ message: `Agendamento ${id} cancelado com sucesso.` });
});


const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
